import hashlib
import time
from argon2 import PasswordHasher

parola = b"guclu_parola_123"

# --- 1. SHA-256 SÜRE ÖLÇÜMÜ ---
# SHA-256 o kadar hızlıdır ki tek bir işlem sıfıra yakın sürer.
# Bu nedenle 100.000 tekrar yapıp ortalama tekil süreyi de hesaplıyoruz.
tekrar = 100_000

baslangic_sha = time.perf_counter()
for _ in range(tekrar):
    _ = hashlib.sha256(parola).digest()
bitis_sha = time.perf_counter()

toplam_sure_sha = bitis_sha - baslangic_sha
tekil_sure_sha = toplam_sure_sha / tekrar

print("=" * 45)
print("1. SHA-256 TESTİ (100.000 Tekrar):")
print(f"Toplam Süre       : {toplam_sure_sha:.4f} saniye")
print(f"Tek Bir Hash Süresi: {tekil_sure_sha * 1_000_000:.2f} mikrosaniye (µs)")

# --- 2. ARGON2id SÜRE ÖLÇÜMÜ ---
# Argon2id varsayılan parametrelerle (bellek ve CPU maliyetli) tek bir parola hash'ler.
hasher = PasswordHasher()

baslangic_argon = time.perf_counter()
argon_hash = hasher.hash("guclu_parola_123")
bitis_argon = time.perf_counter()

tekil_sure_argon = bitis_argon - baslangic_argon

print("\n2. ARGON2id TESTİ (Tek 1 Parola):")
print(f"Tek Bir Hash Süresi: {tekil_sure_argon * 1_000:.2f} milisaniye (ms)")
print(f"Oluşan Hash Örneği : {argon_hash[:35]}...")
print("=" * 45)

# --- 3. KIYASLAMA ---
kat_farki = tekil_sure_argon / tekil_sure_sha
print(f"\nSONUÇ: Argon2id, tek bir işlemde SHA-256'dan yaklaşık {kat_farki:,.0f} KAT daha yavaş çalıştı.")
print("Açıklama: Bu yavaşlık bir hata değil, kaba kuvvet (brute-force) saldırılarını engellemek için tasarlanmış bir güvenlik özelliğidir.")