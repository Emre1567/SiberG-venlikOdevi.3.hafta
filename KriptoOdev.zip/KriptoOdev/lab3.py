import os
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.backends import default_backend
from cryptography.exceptions import InvalidTag

print("--- 1. BÖLÜM: AES-CTR'DA BİT DEĞİŞTİRME (BIT-FLIPPING) ---")

mesaj = b"Tutar: 100 TL"
anahtar = os.urandom(16)
nonce = os.urandom(16)

# CTR ile Şifreleme
cipher = Cipher(algorithms.AES(anahtar), modes.CTR(nonce), backend=default_backend())
encryptor = cipher.encryptor()
sifreli_ctr = bytearray(encryptor.update(mesaj) + encryptor.finalize())

print(f"Orijinal Mesaj: {mesaj.decode()}")
print(f"Orijinal Şifreli Veri (Hex): {sifreli_ctr.hex()}")

# "1" karakterinin indeksi: "Tutar: 100 TL" -> 7. indeks
hedef_indeks = mesaj.index(b"1")

# Anahtarı bilmeden şifreli metindeki baytı manipüle ediyoruz:
# '1' karakterini '9' karakterine dönüştürmek için XOR maskelemesi yapıyoruz
sifreli_ctr[hedef_indeks] ^= ord("1") ^ ord("9")

# Deşifre Etme (Aynı anahtar ve nonce ile)
decryptor = cipher.decryptor()
cozulen_ctr = decryptor.update(bytes(sifreli_ctr)) + decryptor.finalize()

print(f"Manipüle Edilmiş Şifreli Veri: {sifreli_ctr.hex()}")
print(f"Anahtarsız Değiştirilen Sonuç: {cozulen_ctr.decode('utf-8', errors='replace')}")
print("Sonuç: CTR veri bütünlüğü sağlamaz! Saldırgan tutarı 900 TL yaptı.\n")


print("--- 2. BÖLÜM: AES-GCM İLE TEKRARLAMA ---")

# Slayttaki şablon ile GCM kullanımı
aes_gcm = AESGCM(AESGCM.generate_key(bit_length=128))
nonce_gcm = os.urandom(12)

# GCM ile Şifreleme (Şifreli metin + Kimlik Doğrulama Etiketi/Tag içerir)
sifreli_gcm = bytearray(aes_gcm.encrypt(nonce_gcm, b"Tutar: 100 TL", None))
print(f"GCM Şifreli Veri (Metin + Tag): {sifreli_gcm.hex()}")

# Aynı şekilde '1' karakterine denk gelen indeksteki baytı değiştirelim
sifreli_gcm[7] ^= ord("1") ^ ord("9")

# Manipüle edilmiş veriyi çözmeyi deneyelim
try:
    cozulen_gcm = aes_gcm.decrypt(nonce_gcm, bytes(sifreli_gcm), None)
    print(f"Çözülen Mesaj: {cozulen_gcm.decode()}")
except InvalidTag:
    print("HATA ALINDI: cryptography.exceptions.InvalidTag")
    print("Sonuç: AES-GCM verinin kurcalandığını tespit etti ve çözmeyi reddetti!")