import os
from PIL import Image
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend

# 1. Orijinal resmi aç ve RGB bayt verisini al
img = Image.open("resim.bmp").convert("RGB")
piksel_verisi = img.tobytes()

# 16 baytın katı olması için padding ekleme
kalan = len(piksel_verisi) % 16
if kalan != 0:
    piksel_verisi += b"\x00" * (16 - kalan)

anahtar = os.urandom(16)

# 2. ECB Modu ile Şifreleme
cipher_ecb = Cipher(algorithms.AES(anahtar), modes.ECB(), backend=default_backend())
encryptor_ecb = cipher_ecb.encryptor()
ecb_sifreli = encryptor_ecb.update(piksel_verisi) + encryptor_ecb.finalize()

# Şifreli baytları tekrar resim formatına dönüştürüp kaydet (dolgu kısmını kırparak)
ecb_img = Image.frombytes("RGB", img.size, ecb_sifreli[:len(img.tobytes())])
ecb_img.save("ecb_resim.bmp")

# 3. CTR Modu ile Şifreleme
nonce = os.urandom(16)
cipher_ctr = Cipher(algorithms.AES(anahtar), modes.CTR(nonce), backend=default_backend())
encryptor_ctr = cipher_ctr.encryptor()
ctr_sifreli = encryptor_ctr.update(piksel_verisi) + encryptor_ctr.finalize()

ctr_img = Image.frombytes("RGB", img.size, ctr_sifreli[:len(img.tobytes())])
ctr_img.save("ctr_resim.bmp")

print("Görseller başarıyla oluşturuldu ve düzeltildi!")